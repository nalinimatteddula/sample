package sample;

public class TestJavaBean {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Item item = new Item();
      item.setId(101);
      item.setName("Iphone");
      item.setPrice(100);
      
      System.out.println("Id:"+item.getId());
      System.out.println("Name :"+item.getName());
      System.out.println("Price :"+item.getPrice());
	}

}
