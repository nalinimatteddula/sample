package sample;

public class ArithmaticImpl implements IArithmatic{

	@Override
	public int add(int a, int b) {
		return a+b;
	}
}
