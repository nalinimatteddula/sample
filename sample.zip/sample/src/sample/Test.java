package sample;

public class Test {

	public static void process(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello World!");
		System.out.println("Welcome!");
		
	}

}
