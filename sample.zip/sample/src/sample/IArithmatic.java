package sample;

public interface IArithmatic {
    
	public static final int i=2;
	int add(int a, int b);
}
