package objectclassproj;
import sample.Item;
public class TestEquals {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		String s1 = new String("Good morning");
//		String s2 = new String("Good morning");
		
		Item item1 = new Item(101, "iphone", 500);
		Item item2 = new Item(101, "iphone", 500);
		
		System.out.println(item1.equals(item2));
	}

}
